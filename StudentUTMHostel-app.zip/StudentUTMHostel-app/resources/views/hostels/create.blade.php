@extends('layout')
@section('content')
 
<div class="card">
  <div class="card-header">Hostel Page</div>
  <div class="card-body">
      
      <form action="{{ url('hostels') }}" method="post">
        {!! csrf_field() !!}
        <label>Kolej</label></br>
        <input type="text" name="Kolej" id="Kolej" class="form-control"></br>

        <label>RoomNo</label></br>
        <input type="text" name="RoomNo" id="RoomNo" class="form-control"></br>
        
        <label>Block</label></br>
        <input type="text" name="Block" id="Block" class="form-control"></br>

        <label>RoomType</label></br>
        <input type="text" name="RoomType" id="RoomType" class="form-control"></br>

        <label>Status</label></br>
        <input type="text" name="Status" id="Status" class="form-control"></br>
        
        <input type="submit" value="Save" class="btn btn-success"></br>
    </form>
   
  </div>
</div>
 
@stop