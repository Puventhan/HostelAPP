@extends('layout')
@section('content')
 
 
<div class="card">
  <div class="card-header">hostels Page</div>
  <div class="card-body">
   
 
        <div class="card-body">
        <h5 class="card-title">Kolej : {{ $hostels->name }}</h5>
        <p class="card-text">RoomNo : {{ $hostels->address }}</p>
        <p class="card-text">Block : {{ $hostels->mobile }}</p>
        <p class="card-text">RoomType : {{ $hostels->mobile }}</p>
        <p class="card-text">Status : {{ $hostels->mobile }}</p>

  </div>
       
    </hr>
  
  </div>
</div>
@endsection

