@extends('layout')
@section('content')
    
                <div class="card">
                    <div class="card-header">
                        <h2>Hostel Application</h2>
                    </div>
                    <div class="card-body">
                        <a href="{{ url('/hostels/create') }}" class="btn btn-success btn-sm" title="Add New Hostel">
                            <i class="fa fa-plus" aria-hidden="true"></i> 
                        </a>
                        <br/>
                        <br/>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Kolej</th>
                                        <th>RoomNo</th>
                                        <th>Block</th>
                                        <th>RoomType</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                @foreach($hostels as $item)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $item->Kolej }}</td>
                                        <td>{{ $item->RoomNo }}</td>
                                        <td>{{ $item->Block }}</td>
                                        <td>{{ $item->RoomType }}</td>
                                        <td>{{ $item->Status }}</td>
 
                                        <td>
                                            <a href="{{ url('/hostels/' . $item->id) }}" title="View Hostel"><button class="btn btn-info btn-sm"><i class="fa fa-eye" aria-hidden="true"></i> View</button></a>
                                            <a href="{{ url('/hostels/' . $item->id . '/edit') }}" title="Edit Hostel"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</button></a>
 
                                         <form method="POST" action="{{ url('/hostels' . '/' . $item->id) }}" accept-charset="UTF-8" style="display:inline">
                                                {{ method_field('DELETE') }}
                                                {{ csrf_field() }}
                                                <button type="submit" class="btn btn-danger btn-sm" title="Delete Hostel" onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash-o" aria-hidden="true"></i> Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
 
                    </div>
                </div>
@endsection