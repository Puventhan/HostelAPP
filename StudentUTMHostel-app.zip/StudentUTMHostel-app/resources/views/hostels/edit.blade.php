@extends('layout')
@section('content')
 
<div class="card">
  <div class="card-header">Edit Page</div>
  <div class="card-body">
      
      <form action="{{ url('hostels/' .$hostels->id) }}" method="post">
        {!! csrf_field() !!}
        @method("PATCH")
        <input type="hidden" name="id" id="id" value="{{$hostels->id}}" id="id" />
        <label>Kolej</label></br>
        <input type="text" name="Kolej" id="Kolej" class="form-control"></br>

        <label>RoomNo</label></br>
        <input type="text" name="RoomNo" id="RoomNo" class="form-control"></br>
        
        <label>Block</label></br>
        <input type="text" name="Block" id="Block" class="form-control"></br>

        <label>RoomType</label></br>
        <input type="text" name="RoomType" id="RoomType" class="form-control"></br>

        <label>Status</label></br>
        <input type="text" name="Status" id="Status" class="form-control"></br>

        <input type="submit" value="Update" class="btn btn-success"></br>
    </form>
   
  </div>
</div>
 
@stop