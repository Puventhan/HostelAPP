@extends('layout')
@section('content')
 
<div class="card">
  <div class="card-header">Maintenances Page</div>
  <div class="card-body">
      
      <form action="{{ url('Maintenances') }}" method="post">
        {!! csrf_field() !!}
        <label>Damage Location</label></br>
        <input type="text" name="DamageLocation" id="DamageLocation" class="form-control"></br>
        
        <label>Floor</label></br>
        <input type="text" name="floor" id="floor" class="form-control"></br>
        
        <label>Room Number</label></br>
        <input type="text" name="roomNumber" id="roomNumber" class="form-control"></br>

        <label>Description</label></br>
        <input type="text" name="Description" id="Description" class="form-control"></br>
        
        <label>Mobile</label></br>
        <input type="text" name="Mobile" id="Mobile" class="form-control"></br>
        
        <input type="submit" value="Save" class="btn btn-success"></br>
    </form>
   
  </div>
</div>
 
@stop