@extends('layout')
@section('content')
 
 
<div class="card">
  <div class="card-header">Maintenances Page</div>
  <div class="card-body">
   
 
        <div class="card-body">
        <h5 class="card-title">Damage Location : {{ $Maintenances->DamageLocation }}</h5>
        <p class="card-text">floor : {{ $Maintenances->floor }}</p>
        <p class="card-text">roomNo : {{ $Maintenances->roomNo }}</p>
        <p class="card-text">Description : {{ $Maintenances->Description }}</p>
        <p class="card-text">Mobile : {{ $Maintenances->mobile }}</p>
  </div>
       
    </hr>
  
  </div>
</div>
@endsection