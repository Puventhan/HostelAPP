@extends('layout')
@section('content')
 
<div class="card">
  <div class="card-header">Edit Page</div>
  <div class="card-body">
      
      <form action="{{ url('Maintenances/' .$Maintenances->id) }}" method="post">
        {!! csrf_field() !!}
        @method("PATCH")
        <input type="hidden" name="id" id="id" value="{{$Maintenances->id}}" id="id" />
        <label>Damage Location</label></br>
        <input type="text" name="DamageLocation" id="name" value="{{$Maintenances->DamageLocation}}" class="form-control"></br>
        
        <label>Floor</label></br>
        <input type="text" name="floor" id="floor" value="{{$Maintenances->floor}}" class="form-control"></br>
        
        <label>Room Number</label></br>
        <input type="text" name="roomNumber" id="roomNumber" value="{{$Maintenances->roomNumber}}" class="form-control"></br>
        
        <label>Description</label></br>
        <input type="text" name="Description" id="Description" value="{{$Maintenances->Description}}" class="form-control"></br>
        
        <label>Mobile</label></br>
        <input type="text" name="Mobile" id="Mobile" value="{{$Maintenances->Mobile}}" class="form-control"></br>

        <input type="submit" value="Update" class="btn btn-success"></br>
    </form>
   
  </div>
</div>
 
@stop