
<?php $__env->startSection('content'); ?>
 
<div class="card">
  <div class="card-header">Edit Page</div>
  <div class="card-body">
      
      <form action="<?php echo e(url('Maintenances/' .$Maintenances->id)); ?>" method="post">
        <?php echo csrf_field(); ?>

        <?php echo method_field("PATCH"); ?>
        <input type="hidden" name="id" id="id" value="<?php echo e($Maintenances->id); ?>" id="id" />
        <label>Damage Location</label></br>
        <input type="text" name="DamageLocation" id="name" value="<?php echo e($Maintenances->DamageLocation); ?>" class="form-control"></br>
        
        <label>Floor</label></br>
        <input type="text" name="floor" id="floor" value="<?php echo e($Maintenances->floor); ?>" class="form-control"></br>
        
        <label>Room Number</label></br>
        <input type="text" name="roomNumber" id="roomNumber" value="<?php echo e($Maintenances->roomNumber); ?>" class="form-control"></br>
        
        <label>Description</label></br>
        <input type="text" name="Description" id="Description" value="<?php echo e($Maintenances->Description); ?>" class="form-control"></br>
        
        <label>Mobile</label></br>
        <input type="text" name="Mobile" id="Mobile" value="<?php echo e($Maintenances->Mobile); ?>" class="form-control"></br>

        <input type="submit" value="Update" class="btn btn-success"></br>
    </form>
   
  </div>
</div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\puven\OneDrive\Desktop\Laravel\StudentUTMHostel\StudentUTMHostel-app\resources\views/Maintenances/edit.blade.php ENDPATH**/ ?>