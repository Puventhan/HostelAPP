
<?php $__env->startSection('content'); ?>
 
<div class="card">
  <div class="card-header">Hostel Page</div>
  <div class="card-body">
      
      <form action="<?php echo e(url('hostels')); ?>" method="post">
        <?php echo csrf_field(); ?>

        <label>Kolej</label></br>
        <input type="text" name="Kolej" id="Kolej" class="form-control"></br>

        <label>RoomNo</label></br>
        <input type="text" name="RoomNo" id="RoomNo" class="form-control"></br>
        
        <label>Block</label></br>
        <input type="text" name="Block" id="Block" class="form-control"></br>

        <label>RoomType</label></br>
        <input type="text" name="RoomType" id="RoomType" class="form-control"></br>

        <label>Status</label></br>
        <input type="text" name="Status" id="Status" class="form-control"></br>
        
        <input type="submit" value="Save" class="btn btn-success"></br>
    </form>
   
  </div>
</div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\puven\OneDrive\Desktop\Laravel\StudentUTMHostel\StudentUTMHostel-app\resources\views/hostels/create.blade.php ENDPATH**/ ?>