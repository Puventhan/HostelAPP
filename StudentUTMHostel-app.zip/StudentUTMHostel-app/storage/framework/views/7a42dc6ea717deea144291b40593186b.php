
<?php $__env->startSection('content'); ?>
 
 
<div class="card">
  <div class="card-header">Maintenances Page</div>
  <div class="card-body">
   
 
        <div class="card-body">
        <h5 class="card-title">Damage Location : <?php echo e($Maintenances->DamageLocation); ?></h5>
        <p class="card-text">floor : <?php echo e($Maintenances->floor); ?></p>
        <p class="card-text">roomNo : <?php echo e($Maintenances->roomNo); ?></p>
        <p class="card-text">Description : <?php echo e($Maintenances->Description); ?></p>
        <p class="card-text">Mobile : <?php echo e($Maintenances->mobile); ?></p>
  </div>
       
    </hr>
  
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\puven\OneDrive\Desktop\Laravel\StudentUTMHostel\StudentUTMHostel-app\resources\views/Maintenances/show.blade.php ENDPATH**/ ?>