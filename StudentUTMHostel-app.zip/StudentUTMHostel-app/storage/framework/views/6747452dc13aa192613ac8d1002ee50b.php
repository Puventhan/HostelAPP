
<?php $__env->startSection('content'); ?>
    
                <div class="card">
                    <div class="card-header">
                        <h2>Hostel Application</h2>
                    </div>
                    <div class="card-body">
                        <a href="<?php echo e(url('/hostels/create')); ?>" class="btn btn-success btn-sm" title="Add New Hostel">
                            <i class="fa fa-plus" aria-hidden="true"></i> 
                        </a>
                        <br/>
                        <br/>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Kolej</th>
                                        <th>RoomNo</th>
                                        <th>Block</th>
                                        <th>RoomType</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $hostels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->Kolej); ?></td>
                                        <td><?php echo e($item->RoomNo); ?></td>
                                        <td><?php echo e($item->Block); ?></td>
                                        <td><?php echo e($item->RoomType); ?></td>
                                        <td><?php echo e($item->Status); ?></td>
 
                                        <td>
                                            <a href="<?php echo e(url('/hostels/' . $item->id)); ?>" title="View Hostel"><button class="btn btn-info btn-sm"><i class="fa fa-eye" aria-hidden="true"></i> View</button></a>
                                            <a href="<?php echo e(url('/hostels/' . $item->id . '/edit')); ?>" title="Edit Hostel"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</button></a>
 
                                         <form method="POST" action="<?php echo e(url('/hostels' . '/' . $item->id)); ?>" accept-charset="UTF-8" style="display:inline">
                                                <?php echo e(method_field('DELETE')); ?>

                                                <?php echo e(csrf_field()); ?>

                                                <button type="submit" class="btn btn-danger btn-sm" title="Delete Hostel" onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash-o" aria-hidden="true"></i> Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
 
                    </div>
                </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\puven\OneDrive\Desktop\Laravel\StudentUTMHostel\StudentUTMHostel-app\resources\views/hostels/index.blade.php ENDPATH**/ ?>