<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Maintenance extends Model
{
    protected $table = 'maintenances';
    protected $primaryKey = 'id';
    protected $fillable = ['DamageLocation', 'floor', 'roomNo','Description','mobile'];
    use HasFactory;
}


