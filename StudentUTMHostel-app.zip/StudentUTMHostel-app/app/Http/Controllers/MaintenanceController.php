<?php

namespace App\Http\Controllers;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Models\Maintenance;
use Illuminate\View\View;


class MaintenanceController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(): View 
    {
        $Maintenances = Maintenance::all();
        return view ('Maintenances.index')->with('Maintenances', $Maintenances);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(): View
    {
        return view('Maintenances.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request): RedirectResponse
    {
        $input = $request->all();
        Maintenance::create($input);
       // Maintenance::create($input); //Error here 
        return redirect('Maintenances')->with('flash_message', 'Maintenance Addedd!');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id):View
    {
        $Maintenances = Maintenance::find($id);
        return view('Maintenances.show')->with('Maintenances', $Maintenances);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $Maintenances = Maintenance::find($id);
        return view('Maintenances.edit')->with('Maintenances', $Maintenances);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id):RedirectResponse
    {
        $Maintenance = Maintenance::find($id);
        $input = $request->all();
        $Maintenance->update($input);
        return redirect('Maintenances')->with('flash_message', 'Maintenance Updated!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id):RedirectResponse
    {
        Maintenance::destroy($id);
        return redirect('Maintenances')->with('flash_message', 'Maintenance deleted!');
    }
}
