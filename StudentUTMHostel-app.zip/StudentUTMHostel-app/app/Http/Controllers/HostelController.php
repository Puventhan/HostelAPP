<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Hostel;
use Illuminate\View\View;

class HostelController extends Controller
{
     /**
     * Display a listing of the resource.
     */
    public function index(): View 
    {
        $hostels = Hostel::all();
        return view ('hostels.index')->with('hostels', $hostels);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(): View
    {
        return view('hostels.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request): RedirectResponse
    {
        $input = $request->all();
        Hostel::create($input);
        return redirect('hostels')->with('flash_message', 'Hostel Addedd!');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id):View
    {
        $hostels = Hostel::find($id);
        return view('hostels.show')->with('hostels', $hostels);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $hostels = Hostel::find($id);
        return view('hostels.edit')->with('hostels', $hostels);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id):RedirectResponse
    {
        $hostels = Hostel::find($id);
        $input = $request->all();
        $hostels->update($input);
        return redirect('hostels')->with('flash_message', 'Hostel Updated!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id):RedirectResponse
    {
        Hostel::destroy($id);
        return redirect('hostels')->with('flash_message', 'Hostel deleted!');
    }
}
